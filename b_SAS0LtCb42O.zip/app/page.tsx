"use client"

import { useState } from "react"
import { BottomNav } from "@/components/bottom-nav"
import { ProfileScreen } from "@/components/profile-screen"
import { OnlineScreen } from "@/components/online-screen"
import { StatusBar } from "@/components/status-bar"

export default function MobileApp() {
  const [activeTab, setActiveTab] = useState("profile")

  return (
    <div className="min-h-screen max-w-md mx-auto relative overflow-hidden">
      {/* Background with red gradient effect */}
      <div className="fixed inset-0 bg-[#0a0000]">
        {/* Red ambient glow from top center */}
        <div 
          className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px]"
          style={{
            background: "radial-gradient(ellipse at center, rgba(255, 0, 51, 0.25) 0%, rgba(255, 0, 51, 0.1) 30%, transparent 60%)",
          }}
        />
        {/* Secondary glow */}
        <div 
          className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[400px] h-[400px]"
          style={{
            background: "radial-gradient(ellipse at center, rgba(255, 0, 51, 0.15) 0%, transparent 50%)",
          }}
        />
        {/* Dark vignette edges */}
        <div 
          className="absolute inset-0"
          style={{
            background: "radial-gradient(ellipse at center, transparent 30%, rgba(0, 0, 0, 0.6) 100%)",
          }}
        />
      </div>

      {/* Status Bar */}
      <StatusBar />

      {/* Content */}
      <div className="relative z-10">
        {activeTab === "profile" && <ProfileScreen />}
        {activeTab === "online" && <OnlineScreen />}
        {activeTab === "staking" && (
          <div className="min-h-screen flex items-center justify-center pb-28">
            <p className="text-white/60">Стайкинг</p>
          </div>
        )}
        {activeTab === "solo" && (
          <div className="min-h-screen flex items-center justify-center pb-28">
            <p className="text-white/60">Соло</p>
          </div>
        )}
        {activeTab === "tournament" && (
          <div className="min-h-screen flex items-center justify-center pb-28">
            <p className="text-white/60">Турнир</p>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  )
}
