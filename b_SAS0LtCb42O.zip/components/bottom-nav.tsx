"use client"

import { Diamond, Gamepad2, Swords, Trophy, User } from "lucide-react"

interface BottomNavProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  const tabs = [
    { id: "staking", label: "Стайкинг", icon: Diamond },
    { id: "solo", label: "Соло", icon: Gamepad2 },
    { id: "online", label: "Онлайн", icon: Swords },
    { id: "tournament", label: "Турнир", icon: Trophy },
    { id: "profile", label: "Профиль", icon: User },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 nav-glass z-50">
      <div className="flex items-end justify-around px-2 pb-6 pt-2 max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon
          const isCenter = tab.id === "online"
          const isActive = activeTab === tab.id

          if (isCenter) {
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className="relative -mt-6 flex flex-col items-center"
              >
                <div className="center-nav-button w-16 h-16 rounded-full flex items-center justify-center mb-1">
                  <Icon className="w-7 h-7 text-[#ff0033]" />
                </div>
                <span className={`text-xs ${isActive ? "text-[#ff0033]" : "text-white/60"}`}>
                  {tab.label}
                </span>
              </button>
            )
          }

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className="flex flex-col items-center gap-1 py-2 px-3 relative"
            >
              <Icon 
                className={`w-6 h-6 ${isActive ? "text-[#ff0033]" : "text-white/50"}`} 
              />
              <span className={`text-xs ${isActive ? "text-[#ff0033]" : "text-white/50"}`}>
                {tab.label}
              </span>
              {isActive && tab.id === "profile" && (
                <div className="absolute -top-1 -right-1">
                  <div className="w-2 h-2 bg-[#ff0033] rounded-full animate-pulse" />
                </div>
              )}
            </button>
          )
        })}
      </div>
    </div>
  )
}
