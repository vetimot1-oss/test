"use client"

import { Crown, Plus, Rocket, Swords, TrendingUp, Wallet, X } from "lucide-react"

export function OnlineScreen() {
  return (
    <div className="min-h-screen pb-28 px-4 pt-4">
      {/* Header with Balance */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <div className="glass-card-item rounded-xl px-4 py-2 flex items-center gap-2">
            <svg viewBox="0 0 24 24" className="w-5 h-5 text-[#ff0033]" fill="currentColor">
              <path d="M12 2L2 9l10 7 10-7-10-7zM2 17l10 7 10-7M2 12l10 7 10-7"/>
            </svg>
            <span className="text-white font-semibold">14,250</span>
            <button className="w-5 h-5 rounded-full bg-[#ff0033]/30 flex items-center justify-center">
              <Plus className="w-3 h-3 text-[#ff0033]" />
            </button>
          </div>
        </div>
        
        <button className="glass-card-item rounded-xl px-4 py-2 flex items-center gap-2">
          <Wallet className="w-5 h-5 text-[#ff0033]" />
          <span className="text-white/80 text-sm">Кошелек</span>
        </button>
      </div>

      {/* Title */}
      <h1 className="text-white text-2xl font-bold text-center mb-6">Онлайн игры</h1>

      {/* Battle Card */}
      <div className="glass-card glass-shine game-card rounded-3xl p-4 mb-4">
        <div className="flex items-start justify-between">
          <div>
            <div className="w-10 h-10 rounded-full border border-[#ff0033]/50 flex items-center justify-center mb-3 bg-[#ff0033]/10">
              <X className="w-5 h-5 text-[#ff0033]" />
            </div>
            <h3 className="text-white text-xl font-bold mb-1">Битва</h3>
            <p className="text-white/60 text-sm">Сражайся за одну из команд!</p>
          </div>
          <div className="relative">
            <Swords className="w-20 h-20 text-[#ff0033]/40 rotate-45" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#ff0033]/20 to-transparent rounded-full blur-xl" />
          </div>
        </div>
      </div>

      {/* Jackpot Card */}
      <div className="glass-card glass-shine game-card rounded-3xl p-4 mb-4">
        <div className="flex items-start justify-between">
          <div>
            <div className="w-10 h-10 rounded-full border border-[#ff0033]/50 flex items-center justify-center mb-3 bg-[#ff0033]/10">
              <Crown className="w-5 h-5 text-[#ff0033]" />
            </div>
            <h3 className="text-white text-xl font-bold mb-1">Джекпот</h3>
            <p className="text-white/60 text-sm">Сражайся с другими игроками!</p>
          </div>
          <div className="relative flex items-center">
            <Crown className="w-14 h-14 text-[#ff0033]/60" />
            <Crown className="w-20 h-20 text-[#ff0033]/80 -ml-4" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#ff0033]/20 to-transparent rounded-full blur-xl" />
          </div>
        </div>
      </div>

      {/* Game Cards Row */}
      <div className="grid grid-cols-2 gap-4">
        {/* Crash Card */}
        <div className="glass-card glass-shine game-card rounded-3xl p-4 relative overflow-hidden">
          <div className="absolute top-3 right-3">
            <span className="badge-new text-[#ff0033] text-xs px-2 py-1 rounded-full">New!</span>
          </div>
          <div className="w-8 h-8 rounded-full border border-[#ff0033]/50 flex items-center justify-center mb-12 bg-[#ff0033]/10">
            <TrendingUp className="w-4 h-4 text-[#ff0033]" />
          </div>
          <div className="relative mb-3">
            <div className="flex items-end gap-1">
              <TrendingUp className="w-10 h-10 text-[#ff0033]/70" />
              <TrendingUp className="w-14 h-14 text-[#ff0033]/90 -ml-3" />
            </div>
            <Rocket className="w-12 h-12 text-[#ff0033] absolute -right-1 top-0 -rotate-45" />
          </div>
          <h3 className="text-white text-lg font-bold mb-1">Краш</h3>
          <p className="text-white/60 text-xs">Вовремя остановись!</p>
        </div>

        {/* Cash or Crash Card */}
        <div className="glass-card glass-shine game-card rounded-3xl p-4 relative overflow-hidden opacity-80">
          <div className="absolute top-3 right-3">
            <span className="badge-soon text-white/60 text-xs px-2 py-1 rounded-full">Soon...</span>
          </div>
          <div className="w-8 h-8 rounded-full border border-white/30 flex items-center justify-center mb-12 bg-white/5">
            <TrendingUp className="w-4 h-4 text-white/50" />
          </div>
          <div className="relative mb-3 flex justify-center">
            <Rocket className="w-16 h-16 text-[#ff0033]/60 -rotate-45" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#ff0033]/10 to-transparent rounded-full blur-lg" />
          </div>
          <h3 className="text-white text-lg font-bold mb-1">Cash or Crash</h3>
          <p className="text-white/60 text-xs">Поднимойся ввысь</p>
        </div>
      </div>
    </div>
  )
}
