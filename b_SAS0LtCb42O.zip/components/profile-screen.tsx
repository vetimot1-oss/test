"use client"

import { ArrowDown, ArrowRight, ArrowUp, Gift } from "lucide-react"

export function ProfileScreen() {
  return (
    <div className="min-h-screen pb-32 px-4 pt-16">
      {/* Profile Section */}
      <div className="flex flex-col items-center mb-6">
        {/* Avatar with neon glow */}
        <div className="avatar-glow rounded-full p-[3px] mb-3 bg-gradient-to-br from-gray-500/40 to-gray-700/40">
          <div className="w-[88px] h-[88px] rounded-full overflow-hidden bg-gradient-to-br from-gray-600/50 to-gray-800/50 flex items-center justify-center">
            {/* Placeholder avatar silhouette */}
            <svg viewBox="0 0 100 100" className="w-full h-full opacity-60">
              <circle cx="50" cy="35" r="20" fill="rgba(255,255,255,0.3)" />
              <ellipse cx="50" cy="85" rx="30" ry="25" fill="rgba(255,255,255,0.3)" />
            </svg>
          </div>
        </div>
        
        {/* Username */}
        <h2 className="text-white text-xl font-semibold tracking-wide">ensare</h2>
        <p className="text-[#ff0033]/60 text-sm">ensare</p>
      </div>

      {/* Balance Section */}
      <div className="text-center mb-5">
        <p className="text-white/50 text-sm mb-2 tracking-wide">Ваш баланс</p>
        <div className="flex items-center justify-center gap-3">
          {/* Diamond/Crystal icon */}
          <svg viewBox="0 0 24 24" className="w-9 h-9 text-[#ff0033] text-glow" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M12 2L2 9l10 13 10-13-10-7z" />
            <path d="M2 9h20" />
            <path d="M12 2v7" />
            <path d="M7.5 9L12 22l4.5-13" />
          </svg>
          <span className="text-[42px] font-bold text-white tracking-tight text-glow">0.00</span>
        </div>
      </div>

      {/* Wallet Panel - Main Glass Container */}
      <div className="glass-panel glass-shine rounded-[28px] p-5 mb-5">
        {/* Wallet Header */}
        <div className="flex items-center justify-between mb-5">
          <span className="text-white/70 text-lg font-medium">Кошелек</span>
          <button className="wallet-button px-5 py-2.5 rounded-2xl">
            <span className="text-white/80 text-sm font-medium">Подключить</span>
          </button>
        </div>

        {/* Action Buttons - Deposit & Withdraw */}
        <div className="grid grid-cols-2 gap-3 mb-3">
          <button className="glass-button rounded-[20px] py-4 flex items-center justify-center gap-3">
            <div className="icon-circle w-9 h-9 rounded-full flex items-center justify-center">
              <ArrowDown className="w-4 h-4 text-[#ff0033]" />
            </div>
            <span className="text-white font-medium text-[15px]">Пополнить</span>
          </button>
          <button className="glass-button rounded-[20px] py-4 flex items-center justify-center gap-3">
            <div className="icon-circle w-9 h-9 rounded-full flex items-center justify-center">
              <ArrowUp className="w-4 h-4 text-[#ff0033]" />
            </div>
            <span className="text-white font-medium text-[15px]">Вывести</span>
          </button>
        </div>

        {/* Transfer Button */}
        <button className="glass-button rounded-[20px] py-4 w-full">
          <span className="text-white font-medium text-[15px]">Перевод</span>
        </button>
      </div>

      {/* Inventory Section */}
      <div className="mb-5">
        <div className="flex items-center justify-center mb-4">
          <div className="h-[1px] section-divider flex-1" />
          <span className="text-white/50 text-sm px-4 tracking-wide">Инвентарь</span>
          <div className="h-[1px] section-divider flex-1" />
        </div>
        
        <div className="grid grid-cols-3 gap-3">
          <div className="grid-item rounded-[18px] aspect-square flex items-center justify-center">
            <Gift className="w-8 h-8 text-[#ff0033]/50" strokeWidth={1.5} />
          </div>
          <div className="grid-item rounded-[18px] aspect-square flex items-center justify-center">
            <Gift className="w-8 h-8 text-[#ff0033]/50" strokeWidth={1.5} />
          </div>
          <div className="grid-item rounded-[18px] aspect-square flex items-center justify-center">
            <ArrowRight className="w-6 h-6 text-[#ff0033]/50" strokeWidth={1.5} />
          </div>
        </div>
      </div>

      {/* Blockchain Section */}
      <div>
        <div className="flex items-center justify-center mb-4">
          <div className="h-[1px] section-divider flex-1" />
          <span className="text-white/50 text-sm px-4 tracking-wide">Блокчейн</span>
          <div className="h-[1px] section-divider flex-1" />
        </div>
        
        <div className="grid grid-cols-3 gap-3">
          <div className="grid-item rounded-[18px] aspect-square flex items-center justify-center">
            <Gift className="w-8 h-8 text-[#ff0033]/50" strokeWidth={1.5} />
          </div>
          <div className="grid-item rounded-[18px] aspect-square flex items-center justify-center" />
          <div className="grid-item rounded-[18px] aspect-square flex items-center justify-center">
            <ArrowRight className="w-6 h-6 text-[#ff0033]/50" strokeWidth={1.5} />
          </div>
        </div>
      </div>
    </div>
  )
}
