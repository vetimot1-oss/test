"use client"

import { Battery, Signal, Wifi } from "lucide-react"

export function StatusBar() {
  return (
    <div className="fixed top-0 left-0 right-0 z-50 px-6 py-3 flex items-center justify-between bg-gradient-to-b from-black/50 to-transparent">
      <span className="text-white text-sm font-semibold">11:30</span>
      <div className="flex items-center gap-1.5">
        <Signal className="w-4 h-4 text-white" />
        <Wifi className="w-4 h-4 text-white" />
        <div className="flex items-center gap-0.5">
          <Battery className="w-5 h-5 text-white" />
          <span className="text-white text-xs">11</span>
        </div>
      </div>
    </div>
  )
}
